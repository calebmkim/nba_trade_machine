type work_log = {
  caleb : float;
  tinsae : float;
  karan : float;
  pranay : float;
}

let hours_worked_per_member =
  { caleb = 10.; tinsae = 8.; karan = 8.; pranay = 8. }

let hours_worked = 34.
