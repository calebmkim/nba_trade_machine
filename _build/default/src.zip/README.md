# final_project
Final Project for CS3110

NBA Player Data Json from this github repo: alexnoob/BasketBall-GM-Rosters (https://github.com/alexnoob/BasketBall-GM-Rosters) 
